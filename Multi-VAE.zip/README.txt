# settings in main.py

TEST = Ture
# when TEST = Ture, the code just test the trained Multi-VAE model
# when TEST = False, the code will train Multi-VAE model 

# run the code：
python main.py

# visual the generative model：
python Load_model_visual.py